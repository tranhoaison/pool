var api = "http://35.193.128.38:8117";

var poolHost = "35.193.128.38";

var irc = "irc.freenode.net/#poolhost";

var email = "support@poolhost.com";

var cryptonatorWidget = ["{symbol}-BTC", "{symbol}-USD", "{symbol}-EUR"];

var easyminerDownload = "https://github.com/zone117x/cryptonote-easy-miner/releases/";

var blockchainExplorer = "https://explore.leviarcoin.org/block/{id}";

var transactionExplorer = "https://explore.leviarcoin.org/transaction/{id}";


var themeCss = "themes/default-theme.css";
